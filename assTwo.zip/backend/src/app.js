const express = require("express");
const app = express();
const path = require('path');
const ejs = require("ejs");

require("./db/conn");
const Register = require("./models/registers")

const port = process.env.PORT || 3000;

const static_path = path.join(__dirname, "../public");
const template_path = path.join(__dirname, "../templates/views");

//middle wares
app.use(express.json());
app.use(express.urlencoded({extended: false}));

app.use(express.static(static_path));
app.set('view engine', 'ejs');
app.set('views', template_path);

app.get('/', (req, res) => {
    res.render('adminpage');
});

app.get('/show', (req, res) => {
    res.render('index');
});

app.put('/edit', (req, res) => {
    res.render('index');
});
app.delete('/delete', (req, res) => {
    res.send("DELETE Request Called")
})

// create a new adminData in database
app.post('/', async(req, res) => {
    try{
        const registerEmployee = new Register({
            no: req.body.no,
            image: req.body.image,
            name: req.body.name,
            detail: req.body.detail,
            action: req.body.action

        })

        const registered = await registerEmployee.save();
        res.status(201).render('index');
    } 
    catch(error)
    {
        res.send(400).send(error);
    }
});

app.get('/show', (req, res) => {
    res.render('index');
});

app.put('/edit', (req, res) => {
    res.render('index');
});
app.delete('/delete', (req, res) => {
    res.send("DELETE Request Called")
})
//server configurations
app.listen(port, () => {
    console.log(`server is running at port no. ${port}`);
})