
const mongoose = require("mongoose");

const bookingSchema = new mongoose.Schema({

    No:{
        type:Number,
    },
    image:{
        type:String,
    },
    name:{
        type:String,
    },
    detail:{
        type:String,
    },
})

//Now we need to create a collection
const Register = new mongoose.model("Register", bookingSchema);

module.exports = Register;